package com.example.roadrunner_geolab.SurfaceDoctor;

public interface SurfaceDoctorInterface {

    void onSurfaceDoctorEvent(SurfaceDoctorEvent surfaceDoctorEvent);
}
